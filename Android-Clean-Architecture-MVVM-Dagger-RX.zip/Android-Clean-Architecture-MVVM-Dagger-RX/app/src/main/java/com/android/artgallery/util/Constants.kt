package com.android.artgallery.util


/**
 * Contains fixed values that remains during execution once it is initialized
 */
object Constants {

     const val BASE_URL = "https://jsonplaceholder.typicode.com/"

}