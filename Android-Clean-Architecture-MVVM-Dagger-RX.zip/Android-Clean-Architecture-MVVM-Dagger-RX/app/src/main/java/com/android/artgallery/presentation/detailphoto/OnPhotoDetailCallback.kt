package com.android.artgallery.presentation.detailphoto

/**
 * To make an interaction between [PhotoDetailActivity] & its child
 * */
interface OnPhotoDetailCallback{}