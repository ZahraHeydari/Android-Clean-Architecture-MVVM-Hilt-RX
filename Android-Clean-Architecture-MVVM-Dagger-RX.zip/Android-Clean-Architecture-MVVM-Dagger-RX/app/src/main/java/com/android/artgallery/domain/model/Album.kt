package com.android.artgallery.domain.model


data class Album(var userId:Long, var id:Long, var title:String)